
    var colors = {
        root: '#f54',
        port: '#377',
        device: '#252',
        site: '#525',
        edge: '#49a',
        white: '#eed',
        grey: '#555',
        selected: '#ff0'
    };

    var styles = [];

    var cy = window.cy = cytoscape({
    container: document.getElementById('cy'),

    boxSelectionEnabled: true,
    autounselectify: true,

    style: [
        {
            selector: 'node',
            css: {
                'content': 'data(label)',
                'text-valign': 'center',
                'text-halign': 'center',
                'background-color': '#666666',
                'border-color': '#000000',
                'border-width': '1px',
                'color': '#ffffff'
            }
        },
        {
            selector: '$node > node',
            css: {
                'shape': 'roundrectangle',
                'padding-top': '10px',
                'padding-left': '10px',
                'padding-bottom': '10px',
                'padding-right': '10px',
                'text-valign': 'center',
                'text-halign': 'center',
                'background-color': '#ffffff',
                'color': '#444444',
                'border-color': '#888888'
            }
        },
        {
            selector: 'node[layer = "OTSi"]',
            css: {
                'content': 'data(label)',
                'text-valign': 'center',
                'text-halign': 'center',
                'background-color': '#008800',
                'border-color': '#004400',
                'border-width': '1px',
                'color': '#ffffff',
                'font-weight': 'bold'
            }
        },
        {
            selector: 'node[type = "Direction"]',
            css: {
                'content': 'data(label)',
                'text-valign': 'center',
                'text-halign': 'center',
                'background-color': '#ffddff',
                'border-color': '#884488',
                'border-width': '1px',
                'color': '#444444'
            }
        },
        {
            selector: 'node[type = "Direction"][layer = "OTSi"]',
            css: {
                'content': 'data("")',
                'background-opacity': 0,
                'border-width': '0px'
            }
        },
        {
            selector: 'node[type = "RODAM"]',
            css: {
                'shape': 'roundrectangle',
                'padding-top': '10px',
                'padding-left': '10px',
                'padding-bottom': '10px',
                'padding-right': '10px',
                'text-valign': 'center',
                'text-halign': 'center',
                'background-color': '#ffffdd',
                'color': '#444444',
                'border-color': '#888844',
                'font-weight': 'bold'
            }
        },
        {
            selector: 'node[type = "Transponder"]',
            css: {
                'shape': 'roundrectangle',
                'padding-top': '10px',
                'padding-left': '10px',
                'padding-bottom': '10px',
                'padding-right': '10px',
                'text-valign': 'center',
                'text-halign': 'center',
                'background-color': '#ffffdd',
                'color': '#444444',
                'border-color': '#888844',
                'font-weight': 'bold'
            }
        },

        {
            selector: 'node[type = "device"][active = "true"]',
            css: {
                'background-color': '#316ac5',
                'background-opacity': '0.3',
                'border-color': '#316ac5',
                'border-width': '2px',
                'color': '#444444'
            }
        },
        {
            selector: 'node[type = "port"][active = "true"]',
            css: {
                'background-opacity': '1.0',
            }
        },
        {
            selector: 'node[active = "false"]',
            css: {
                'background-opacity': '0.3',
                'border-opacity': '0.5'
            }
        },

        {
            selector: 'edge',
            css: {
                'content': 'data("")',
                'curve-style': 'unbundled-bezier',
                'control-point-distance': '30px',
                'control-point-weight': '0.5', 
                'width': 5,
                'source-arrow-shape': 'none',
                'target-arrow-shape': 'none',
                'line-color': '#ff0000',
                'color': '#444444'
            }
        },
        {
            selector: 'edge[type = "route"]',
            css: {
                'content': 'data("")',
                'curve-style': 'haystack',
                'width': 20,
                'source-arrow-shape': 'none',
                'target-arrow-shape': 'none',
                'line-color': '#0000ff',
                'color': '#444444'
            }
        },
    ],

    elements: {
        nodes: [

            { data: { id: '-domainADVA', label : 'ADVA' , parent : '', type : 'Domain' } },
            { data: { id: '-domainCoriant', label : 'Coriant' , parent : '', type : 'Domain' } },
            
            { data: { id: '-domainADVA-roadm1', label : 'ADVA-R1' , parent : '-domainADVA', type : 'RODAM', number : 1, 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm2', label : 'ADVA-R2' , parent : '-domainADVA', type : 'RODAM', number : 2, 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm3', label : 'ADVA-R3' , parent : '-domainADVA', type : 'RODAM', number : 3, 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm1', label : 'Coriant-R1' , parent : '-domainCoriant', type : 'RODAM', number : 1, 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm2', label : 'Coriant-R2' , parent : '-domainCoriant', type : 'RODAM', number : 2, 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm3', label : 'Coriant-R3' , parent : '-domainCoriant', type : 'RODAM', number : 3, 'operational-atate' : 'enabled' } },

            { data: { id: '-domainADVA-roadm1-oms1', label : 'OMS1' , parent : '-domainADVA-roadm1', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 1, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm1-oms2', label : 'OMS2' , parent : '-domainADVA-roadm1', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 2, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm1-oms3', label : 'OMS3' , parent : '-domainADVA-roadm1', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 3, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm1-otsi4', label : 'OTSi4' , parent : '-domainADVA-roadm1', type : 'Direction', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm2-oms1', label : 'OMS1' , parent : '-domainADVA-roadm2', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 1, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm2-oms2', label : 'OMS2' , parent : '-domainADVA-roadm2', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 2, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm2-otsi3', label : 'OTSi3' , parent : '-domainADVA-roadm2', type : 'Direction', layer : 'OTSi', 'termination-state' : 'terminated', number : 3, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm3-oms1', label : 'OMS1' , parent : '-domainADVA-roadm3', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 1, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm3-oms2', label : 'OMS2' , parent : '-domainADVA-roadm3', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 2, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm3-oms3', label : 'OMS3' , parent : '-domainADVA-roadm3', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 3, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainADVA-roadm3-otsi4', label : 'OTSi4' , parent : '-domainADVA-roadm3', type : 'Direction', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm1-oms1', label : 'OMS1' , parent : '-domainCoriant-roadm1', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 1, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm1-oms2', label : 'OMS2' , parent : '-domainCoriant-roadm1', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 2, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm1-oms3', label : 'OMS3' , parent : '-domainCoriant-roadm1', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 3, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm1-otsi4', label : 'OTSi4' , parent : '-domainCoriant-roadm1', type : 'Direction', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm2-oms1', label : 'OMS1' , parent : '-domainCoriant-roadm2', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 1, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm2-oms2', label : 'OMS2' , parent : '-domainCoriant-roadm2', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 2, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm2-otsi3', label : 'OTSi3' , parent : '-domainCoriant-roadm2', type : 'Direction', layer : 'OTSi', 'termination-state' : 'terminated', number : 3, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm3-oms1', label : 'OMS1' , parent : '-domainCoriant-roadm3', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 1, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm3-oms2', label : 'OMS2' , parent : '-domainCoriant-roadm3', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 2, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm3-oms3', label : 'OMS3' , parent : '-domainCoriant-roadm3', type : 'Direction', layer : 'OMS', 'termination-state' : 'terminated', number : 3, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },
            { data: { id: '-domainCoriant-roadm3-otsi4', label : 'OTSi4' , parent : '-domainCoriant-roadm3', type : 'Direction', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' } },

            { data: { id: '-domainADVA-roadm1-oms1-channel1', label : '#1' , parent : '-domainADVA-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -421.2, y: 416.4 } },
            { data: { id: '-domainADVA-roadm1-oms1-channel2', label : '#2' , parent : '-domainADVA-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -435.2, y: 382.6 } },
            { data: { id: '-domainADVA-roadm1-oms1-channel3', label : '#3' , parent : '-domainADVA-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -440, y: 346.4 } },
            { data: { id: '-domainADVA-roadm1-oms1-channel4', label : '#4' , parent : '-domainADVA-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -435.2, y: 310.2 } },
            { data: { id: '-domainADVA-roadm1-oms1-channel5', label : '#5' , parent : '-domainADVA-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -421.2, y: 276.4 } },
            { data: { id: '-domainADVA-roadm1-oms2-channel1', label : '#1' , parent : '-domainADVA-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -370, y: 225.2 } },
            { data: { id: '-domainADVA-roadm1-oms2-channel2', label : '#2' , parent : '-domainADVA-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: 211.2 } },
            { data: { id: '-domainADVA-roadm1-oms2-channel3', label : '#3' , parent : '-domainADVA-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -300, y: 206.4 } },
            { data: { id: '-domainADVA-roadm1-oms2-channel4', label : '#4' , parent : '-domainADVA-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: 211.2 } },
            { data: { id: '-domainADVA-roadm1-oms2-channel5', label : '#5' , parent : '-domainADVA-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -230, y: 225.2 } },
            { data: { id: '-domainADVA-roadm1-oms3-channel1', label : '#1' , parent : '-domainADVA-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -178.8, y: 276.4 } },
            { data: { id: '-domainADVA-roadm1-oms3-channel2', label : '#2' , parent : '-domainADVA-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -164.8, y: 310.2 } },
            { data: { id: '-domainADVA-roadm1-oms3-channel3', label : '#3' , parent : '-domainADVA-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -160, y: 346.4 } },
            { data: { id: '-domainADVA-roadm1-oms3-channel4', label : '#4' , parent : '-domainADVA-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -164.8, y: 382.6 } },
            { data: { id: '-domainADVA-roadm1-oms3-channel5', label : '#5' , parent : '-domainADVA-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -178.8, y: 416.4 } },
            { data: { id: '-domainADVA-roadm1-otsi4-channel1', label : '#1' , parent : '-domainADVA-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -230, y: 467.6 } },
            { data: { id: '-domainADVA-roadm1-otsi4-channel2', label : '#2' , parent : '-domainADVA-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: 481.6 } },
            { data: { id: '-domainADVA-roadm1-otsi4-channel3', label : '#3' , parent : '-domainADVA-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -300, y: 486.4 } },
            { data: { id: '-domainADVA-roadm1-otsi4-channel4', label : '#4' , parent : '-domainADVA-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: 481.6 } },
            { data: { id: '-domainADVA-roadm1-otsi4-channel5', label : '#5' , parent : '-domainADVA-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -370, y: 467.6 } },
            { data: { id: '-domainADVA-roadm2-oms1-channel1', label : '#1' , parent : '-domainADVA-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -900, y: -140 } },
            { data: { id: '-domainADVA-roadm2-oms1-channel2', label : '#2' , parent : '-domainADVA-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -863.8, y: -135.2 } },
            { data: { id: '-domainADVA-roadm2-oms1-channel3', label : '#3' , parent : '-domainADVA-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -830, y: -121.2 } },
            { data: { id: '-domainADVA-roadm2-oms1-channel4', label : '#4' , parent : '-domainADVA-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -801, y: -99 } },
            { data: { id: '-domainADVA-roadm2-oms1-channel5', label : '#5' , parent : '-domainADVA-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -778.8, y: -70 } },
            { data: { id: '-domainADVA-roadm2-oms2-channel1', label : '#1' , parent : '-domainADVA-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -778.8, y: 70 } },
            { data: { id: '-domainADVA-roadm2-oms2-channel2', label : '#2' , parent : '-domainADVA-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -801, y: 99 } },
            { data: { id: '-domainADVA-roadm2-oms2-channel3', label : '#3' , parent : '-domainADVA-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -830, y: 121.2 } },
            { data: { id: '-domainADVA-roadm2-oms2-channel4', label : '#4' , parent : '-domainADVA-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -863.8, y: 135.2 } },
            { data: { id: '-domainADVA-roadm2-oms2-channel5', label : '#5' , parent : '-domainADVA-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -900, y: 140 } },
            { data: { id: '-domainADVA-roadm2-otsi3-channel1', label : '#1' , parent : '-domainADVA-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1021.2, y: 70 } },
            { data: { id: '-domainADVA-roadm2-otsi3-channel2', label : '#2' , parent : '-domainADVA-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1035.2, y: 36.2 } },
            { data: { id: '-domainADVA-roadm2-otsi3-channel3', label : '#3' , parent : '-domainADVA-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1040, y: 0 } },
            { data: { id: '-domainADVA-roadm2-otsi3-channel4', label : '#4' , parent : '-domainADVA-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1035.2, y: -36.2 } },
            { data: { id: '-domainADVA-roadm2-otsi3-channel5', label : '#5' , parent : '-domainADVA-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1021.2, y: -70 } },
            { data: { id: '-domainADVA-roadm3-oms1-channel1', label : '#1' , parent : '-domainADVA-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -178.8, y: -416.4 } },
            { data: { id: '-domainADVA-roadm3-oms1-channel2', label : '#2' , parent : '-domainADVA-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -164.8, y: -382.6 } },
            { data: { id: '-domainADVA-roadm3-oms1-channel3', label : '#3' , parent : '-domainADVA-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -160, y: -346.4 } },
            { data: { id: '-domainADVA-roadm3-oms1-channel4', label : '#4' , parent : '-domainADVA-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -164.8, y: -310.2 } },
            { data: { id: '-domainADVA-roadm3-oms1-channel5', label : '#5' , parent : '-domainADVA-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -178.8, y: -276.4 } },
            { data: { id: '-domainADVA-roadm3-oms2-channel1', label : '#1' , parent : '-domainADVA-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -230, y: -225.2 } },
            { data: { id: '-domainADVA-roadm3-oms2-channel2', label : '#2' , parent : '-domainADVA-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: -211.2 } },
            { data: { id: '-domainADVA-roadm3-oms2-channel3', label : '#3' , parent : '-domainADVA-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -300, y: -206.4 } },
            { data: { id: '-domainADVA-roadm3-oms2-channel4', label : '#4' , parent : '-domainADVA-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: -211.2 } },
            { data: { id: '-domainADVA-roadm3-oms2-channel5', label : '#5' , parent : '-domainADVA-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -370, y: -225.2 } },
            { data: { id: '-domainADVA-roadm3-oms3-channel1', label : '#1' , parent : '-domainADVA-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -421.2, y: -276.4 } },
            { data: { id: '-domainADVA-roadm3-oms3-channel2', label : '#2' , parent : '-domainADVA-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -435.2, y: -310.2 } },
            { data: { id: '-domainADVA-roadm3-oms3-channel3', label : '#3' , parent : '-domainADVA-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -440, y: -346.4 } },
            { data: { id: '-domainADVA-roadm3-oms3-channel4', label : '#4' , parent : '-domainADVA-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -435.2, y: -382.6 } },
            { data: { id: '-domainADVA-roadm3-oms3-channel5', label : '#5' , parent : '-domainADVA-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -421.2, y: -416.4 } },
            { data: { id: '-domainADVA-roadm3-otsi4-channel1', label : '#1' , parent : '-domainADVA-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -370, y: -467.6 } },
            { data: { id: '-domainADVA-roadm3-otsi4-channel2', label : '#2' , parent : '-domainADVA-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: -481.6 } },
            { data: { id: '-domainADVA-roadm3-otsi4-channel3', label : '#3' , parent : '-domainADVA-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -300, y: -486.4 } },
            { data: { id: '-domainADVA-roadm3-otsi4-channel4', label : '#4' , parent : '-domainADVA-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: -481.6 } },
            { data: { id: '-domainADVA-roadm3-otsi4-channel5', label : '#5' , parent : '-domainADVA-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -230, y: -467.6 } },
            { data: { id: '-domainCoriant-roadm1-oms1-channel1', label : '#1' , parent : '-domainCoriant-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 421.2, y: -416.4 } },
            { data: { id: '-domainCoriant-roadm1-oms1-channel2', label : '#2' , parent : '-domainCoriant-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 435.2, y: -382.6 } },
            { data: { id: '-domainCoriant-roadm1-oms1-channel3', label : '#3' , parent : '-domainCoriant-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 440, y: -346.4 } },
            { data: { id: '-domainCoriant-roadm1-oms1-channel4', label : '#4' , parent : '-domainCoriant-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 435.2, y: -310.2 } },
            { data: { id: '-domainCoriant-roadm1-oms1-channel5', label : '#5' , parent : '-domainCoriant-roadm1-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 421.2, y: -276.4 } },
            { data: { id: '-domainCoriant-roadm1-oms2-channel1', label : '#1' , parent : '-domainCoriant-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 370, y: -225.2 } },
            { data: { id: '-domainCoriant-roadm1-oms2-channel2', label : '#2' , parent : '-domainCoriant-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: -211.2 } },
            { data: { id: '-domainCoriant-roadm1-oms2-channel3', label : '#3' , parent : '-domainCoriant-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 300, y: -206.4 } },
            { data: { id: '-domainCoriant-roadm1-oms2-channel4', label : '#4' , parent : '-domainCoriant-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: -211.2 } },
            { data: { id: '-domainCoriant-roadm1-oms2-channel5', label : '#5' , parent : '-domainCoriant-roadm1-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 230, y: -225.2 } },
            { data: { id: '-domainCoriant-roadm1-oms3-channel1', label : '#1' , parent : '-domainCoriant-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 178.8, y: -276.4 } },
            { data: { id: '-domainCoriant-roadm1-oms3-channel2', label : '#2' , parent : '-domainCoriant-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 164.8, y: -310.2 } },
            { data: { id: '-domainCoriant-roadm1-oms3-channel3', label : '#3' , parent : '-domainCoriant-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 160, y: -346.4 } },
            { data: { id: '-domainCoriant-roadm1-oms3-channel4', label : '#4' , parent : '-domainCoriant-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 164.8, y: -382.6 } },
            { data: { id: '-domainCoriant-roadm1-oms3-channel5', label : '#5' , parent : '-domainCoriant-roadm1-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 178.8, y: -416.4 } },
            { data: { id: '-domainCoriant-roadm1-otsi4-channel1', label : '#1' , parent : '-domainCoriant-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 230, y: -467.6 } },
            { data: { id: '-domainCoriant-roadm1-otsi4-channel2', label : '#2' , parent : '-domainCoriant-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: -481.6 } },
            { data: { id: '-domainCoriant-roadm1-otsi4-channel3', label : '#3' , parent : '-domainCoriant-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 300, y: -486.4 } },
            { data: { id: '-domainCoriant-roadm1-otsi4-channel4', label : '#4' , parent : '-domainCoriant-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: -481.6 } },
            { data: { id: '-domainCoriant-roadm1-otsi4-channel5', label : '#5' , parent : '-domainCoriant-roadm1-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 370, y: -467.6 } },
            { data: { id: '-domainCoriant-roadm2-oms1-channel1', label : '#1' , parent : '-domainCoriant-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 900, y: 140 } },
            { data: { id: '-domainCoriant-roadm2-oms1-channel2', label : '#2' , parent : '-domainCoriant-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 863.8, y: 135.2 } },
            { data: { id: '-domainCoriant-roadm2-oms1-channel3', label : '#3' , parent : '-domainCoriant-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 830, y: 121.2 } },
            { data: { id: '-domainCoriant-roadm2-oms1-channel4', label : '#4' , parent : '-domainCoriant-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 801, y: 99 } },
            { data: { id: '-domainCoriant-roadm2-oms1-channel5', label : '#5' , parent : '-domainCoriant-roadm2-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 778.8, y: 70 } },
            { data: { id: '-domainCoriant-roadm2-oms2-channel1', label : '#1' , parent : '-domainCoriant-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 778.8, y: -70 } },
            { data: { id: '-domainCoriant-roadm2-oms2-channel2', label : '#2' , parent : '-domainCoriant-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 801, y: -99 } },
            { data: { id: '-domainCoriant-roadm2-oms2-channel3', label : '#3' , parent : '-domainCoriant-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 830, y: -121.2 } },
            { data: { id: '-domainCoriant-roadm2-oms2-channel4', label : '#4' , parent : '-domainCoriant-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 863.8, y: -135.2 } },
            { data: { id: '-domainCoriant-roadm2-oms2-channel5', label : '#5' , parent : '-domainCoriant-roadm2-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 900, y: -140 } },
            { data: { id: '-domainCoriant-roadm2-otsi3-channel1', label : '#1' , parent : '-domainCoriant-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1021.2, y: -70 } },
            { data: { id: '-domainCoriant-roadm2-otsi3-channel2', label : '#2' , parent : '-domainCoriant-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1035.2, y: -36.2 } },
            { data: { id: '-domainCoriant-roadm2-otsi3-channel3', label : '#3' , parent : '-domainCoriant-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1040, y: 0 } },
            { data: { id: '-domainCoriant-roadm2-otsi3-channel4', label : '#4' , parent : '-domainCoriant-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1035.2, y: 36.2 } },
            { data: { id: '-domainCoriant-roadm2-otsi3-channel5', label : '#5' , parent : '-domainCoriant-roadm2-otsi3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1021.2, y: 70 } },
            { data: { id: '-domainCoriant-roadm3-oms1-channel1', label : '#1' , parent : '-domainCoriant-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 178.8, y: 416.4 } },
            { data: { id: '-domainCoriant-roadm3-oms1-channel2', label : '#2' , parent : '-domainCoriant-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 164.8, y: 382.6 } },
            { data: { id: '-domainCoriant-roadm3-oms1-channel3', label : '#3' , parent : '-domainCoriant-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 160, y: 346.4 } },
            { data: { id: '-domainCoriant-roadm3-oms1-channel4', label : '#4' , parent : '-domainCoriant-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 164.8, y: 310.2 } },
            { data: { id: '-domainCoriant-roadm3-oms1-channel5', label : '#5' , parent : '-domainCoriant-roadm3-oms1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 178.8, y: 276.4 } },
            { data: { id: '-domainCoriant-roadm3-oms2-channel1', label : '#1' , parent : '-domainCoriant-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 230, y: 225.2 } },
            { data: { id: '-domainCoriant-roadm3-oms2-channel2', label : '#2' , parent : '-domainCoriant-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: 211.2 } },
            { data: { id: '-domainCoriant-roadm3-oms2-channel3', label : '#3' , parent : '-domainCoriant-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 300, y: 206.4 } },
            { data: { id: '-domainCoriant-roadm3-oms2-channel4', label : '#4' , parent : '-domainCoriant-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: 211.2 } },
            { data: { id: '-domainCoriant-roadm3-oms2-channel5', label : '#5' , parent : '-domainCoriant-roadm3-oms2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 370, y: 225.2 } },
            { data: { id: '-domainCoriant-roadm3-oms3-channel1', label : '#1' , parent : '-domainCoriant-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 421.2, y: 276.4 } },
            { data: { id: '-domainCoriant-roadm3-oms3-channel2', label : '#2' , parent : '-domainCoriant-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 435.2, y: 310.2 } },
            { data: { id: '-domainCoriant-roadm3-oms3-channel3', label : '#3' , parent : '-domainCoriant-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 440, y: 346.4 } },
            { data: { id: '-domainCoriant-roadm3-oms3-channel4', label : '#4' , parent : '-domainCoriant-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 435.2, y: 382.6 } },
            { data: { id: '-domainCoriant-roadm3-oms3-channel5', label : '#5' , parent : '-domainCoriant-roadm3-oms3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 421.2, y: 416.4 } },
            { data: { id: '-domainCoriant-roadm3-otsi4-channel1', label : '#1' , parent : '-domainCoriant-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 1, frequency : 196, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 370, y: 467.6 } },
            { data: { id: '-domainCoriant-roadm3-otsi4-channel2', label : '#2' , parent : '-domainCoriant-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: 481.6 } },
            { data: { id: '-domainCoriant-roadm3-otsi4-channel3', label : '#3' , parent : '-domainCoriant-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 3, frequency : 195.9, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 300, y: 486.4 } },
            { data: { id: '-domainCoriant-roadm3-otsi4-channel4', label : '#4' , parent : '-domainCoriant-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: 481.6 } },
            { data: { id: '-domainCoriant-roadm3-otsi4-channel5', label : '#5' , parent : '-domainCoriant-roadm3-otsi4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'connected', number : 5, frequency : 195.8, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 230, y: 467.6 } },

            { data: { id: 'transponderADVA1', label : 'ADVA-T1' , parent : '', type : 'Transponder', vendor : 'ADVA' } },
            { data: { id: 'transponderCoriant1', label : 'Coriant-T1' , parent : '', type : 'Transponder', vendor : 'Coriant' } },
            { data: { id: 'transponderADVA2', label : 'ADVA-T2' , parent : '', type : 'Transponder', vendor : 'ADVA' } },
            { data: { id: 'transponderCoriant2', label : 'Coriant-T2' , parent : '', type : 'Transponder', vendor : 'Coriant' } },
            { data: { id: 'transponderADVA3', label : 'ADVA-T3' , parent : '', type : 'Transponder', vendor : 'ADVA' } },
            { data: { id: 'transponderCoriant3', label : 'Coriant-T3' , parent : '', type : 'Transponder', vendor : 'Coriant' } },
            { data: { id: 'transponderADVA4', label : 'ADVA-T4' , parent : '', type : 'Transponder', vendor : 'ADVA' } },
            { data: { id: 'transponderCoriant4', label : 'Coriant-T4' , parent : '', type : 'Transponder', vendor : 'Coriant' } },
            { data: { id: 'transponderADVA5', label : 'ADVA-T5' , parent : '', type : 'Transponder', vendor : 'ADVA' } },
            { data: { id: 'transponderCoriant5', label : 'Coriant-T5' , parent : '', type : 'Transponder', vendor : 'Coriant' } },
            { data: { id: 'transponderADVA6', label : 'Coriant-T6' , parent : '', type : 'Transponder', vendor : 'ADVA' } },
            { data: { id: 'transponderCoriant6', label : 'Coriant-T6' , parent : '', type : 'Transponder', vendor : 'Coriant' } },
                        
            { data: { id: 'transponderADVA1-l1', label : 'L1' , parent : 'transponderADVA1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: 621.6 } },
            { data: { id: 'transponderCoriant1-l1', label : 'L1' , parent : 'transponderCoriant1', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: 621.6 } },
            { data: { id: 'transponderADVA2-l2', label : 'L2' , parent : 'transponderADVA2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1175.2, y: 36.2 } },
            { data: { id: 'transponderCoriant2-l2', label : 'L2' , parent : 'transponderCoriant2', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1175.2, y: -36.2 } },
            { data: { id: 'transponderADVA3-l3', label : 'L3' , parent : 'transponderADVA3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: -621.6 } },
            { data: { id: 'transponderCoriant3-l3', label : 'L3' , parent : 'transponderCoriant3', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: -621.6 } },
            { data: { id: 'transponderADVA4-l4', label : 'L4' , parent : 'transponderADVA4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: -621.6 } },
            { data: { id: 'transponderCoriant4-l4', label : 'L4' , parent : 'transponderCoriant4', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: -621.6 } },
            { data: { id: 'transponderADVA5-l5', label : 'L5' , parent : 'transponderADVA5', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1175.2, y: -36.2 } },
            { data: { id: 'transponderCoriant5-l5', label : 'L5' , parent : 'transponderCoriant5', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1175.2, y: 36.2 } },
            { data: { id: 'transponderADVA6-l6', label : 'L6' , parent : 'transponderADVA6', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: 621.6 } },
            { data: { id: 'transponderCoriant6-l6', label : 'L6' , parent : 'transponderCoriant6', type : 'LTP', layer : 'OTSi', 'termination-state' : 'terminated', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: 621.6 } },
            
            { data: { id: 'transponderADVA1-c1', label : 'C1' , parent : 'transponderADVA1', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: 681.6 } },
            { data: { id: 'transponderCoriant1-c1', label : 'C1' , parent : 'transponderCoriant1', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: 681.6 } },
            { data: { id: 'transponderADVA2-c2', label : 'C2' , parent : 'transponderADVA2', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1235.2, y: 36.2 } },
            { data: { id: 'transponderCoriant2-c2', label : 'C2' , parent : 'transponderCoriant2', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -1235.2, y: -36.2 } },
            { data: { id: 'transponderADVA3-c3', label : 'C3' , parent : 'transponderADVA3', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -336.2, y: -681.6 } },
            { data: { id: 'transponderCoriant3-c3', label : 'C3' , parent : 'transponderCoriant3', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: -263.8, y: -681.6 } },
            { data: { id: 'transponderADVA4-c4', label : 'C4' , parent : 'transponderADVA4', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: -681.6 } },
            { data: { id: 'transponderCoriant4-c4', label : 'C4' , parent : 'transponderCoriant4', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: -681.6 } },
            { data: { id: 'transponderADVA5-c5', label : 'C5' , parent : 'transponderADVA5', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1235.2, y: -36.2 } },
            { data: { id: 'transponderCoriant5-c5', label : 'C5' , parent : 'transponderCoriant5', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 1235.2, y: 36.2 } },
            { data: { id: 'transponderADVA6-c6', label : 'C6' , parent : 'transponderADVA6', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 2, frequency : 195.95, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 336.2, y: 681.6 } },
            { data: { id: 'transponderCoriant6-c6', label : 'C6' , parent : 'transponderCoriant6', type : 'LTP', layer : 'ETH', 'termination-state' : 'connected', number : 4, frequency : 195.85, 'physical-port-reference' : 'shelf-1-slot-2-port-3', 'operational-atate' : 'enabled' }, position: { x: 263.8, y: 681.6 } },
                                        
        ],
        edges: [

            { data: { id: '-domainADVA-roadm1-oms1-domainADVA-roadm2-oms2', source: '-domainADVA-roadm1-oms1', target: '-domainADVA-roadm2-oms2', label: 'A12', length: 0, layer: 'OMS' , domain: 'intra', 'operational-state': 'true' } },
            { data: { id: '-domainADVA-roadm2-oms1-domainADVA-roadm3-oms3', source: '-domainADVA-roadm2-oms1', target: '-domainADVA-roadm3-oms3', label: 'A23', length: 0, layer: 'OMS' , domain: 'intra', 'operational-state': 'true' } },
            { data: { id: '-domainADVA-roadm3-oms2-domainADVA-roadm1-oms2', source: '-domainADVA-roadm3-oms2', target: '-domainADVA-roadm1-oms2', label: 'A31', length: 0, layer: 'OMS' , domain: 'intra', 'operational-state': 'true' } },
            { data: { id: '-domainCoriant-roadm1-oms1-domainCoriant-roadm2-oms2', source: '-domainCoriant-roadm1-oms1', target: '-domainCoriant-roadm2-oms2', label: 'C12', length: 0, layer: 'OMS' , domain: 'intra', 'operational-state': 'true' } },
            { data: { id: '-domainCoriant-roadm2-oms1-domainCoriant-roadm3-oms3', source: '-domainCoriant-roadm2-oms1', target: '-domainCoriant-roadm3-oms3', label: 'C23', length: 0, layer: 'OMS' , domain: 'intra', 'operational-state': 'true' } },
            { data: { id: '-domainCoriant-roadm1-oms2-domainCoriant-roadm3-oms2', source: '-domainCoriant-roadm1-oms2', target: '-domainCoriant-roadm3-oms2', label: 'C31', length: 0, layer: 'OMS' , domain: 'intra', 'operational-state': 'true' } },
            { data: { id: '-domainADVA-roadm3-oms1-domainCoriant-roadm1-oms3', source: '-domainADVA-roadm3-oms1', target: '-domainCoriant-roadm1-oms3', label: 'A3-C1', length: 0, layer: 'OMS' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: '-domainCoriant-roadm3-oms1-domainADVA-roadm1-oms3', source: '-domainCoriant-roadm3-oms1', target: '-domainADVA-roadm1-oms3', label: 'C3-A1', length: 0, layer: 'OMS' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant3-c3transponderADVA4-c4', source: 'transponderCoriant3-c3', target: 'transponderADVA4-c4', label: 'CEth3-AETH4', length: 0, layer: 'ETH' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant6-c6transponderADVA1-c1', source: 'transponderCoriant6-c6', target: 'transponderADVA1-c1', label: 'CEth6-AETH1', length: 0, layer: 'ETH' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderADVA1-l1-domainADVA-roadm1-otsi4-channel2', source: 'transponderADVA1-l1', target: '-domainADVA-roadm1-otsi4-channel2', label: 'AT1-AR1', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant1-l1-domainADVA-roadm1-otsi4-channel4', source: 'transponderCoriant1-l1', target: '-domainADVA-roadm1-otsi4-channel4', label: 'CT1-AR1', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderADVA2-l2-domainADVA-roadm2-otsi3-channel2', source: 'transponderADVA2-l2', target: '-domainADVA-roadm2-otsi3-channel2', label: 'AT2-AR2', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant2-l2-domainADVA-roadm2-otsi3-channel4', source: 'transponderCoriant2-l2', target: '-domainADVA-roadm2-otsi3-channel4', label: 'CT2-AR2', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderADVA3-l3-domainADVA-roadm3-otsi4-channel2', source: 'transponderADVA3-l3', target: '-domainADVA-roadm3-otsi4-channel2', label: 'AT3-AR3', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant3-l3-domainADVA-roadm3-otsi4-channel4', source: 'transponderCoriant3-l3', target: '-domainADVA-roadm3-otsi4-channel4', label: 'CT3-AR3', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderADVA4-l4-domainCoriant-roadm1-otsi4-channel2', source: 'transponderADVA4-l4', target: '-domainCoriant-roadm1-otsi4-channel2', label: 'AT4-CR1', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant4-l4-domainCoriant-roadm1-otsi4-channel4', source: 'transponderCoriant4-l4', target: '-domainCoriant-roadm1-otsi4-channel4', label: 'CT4-CR1', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderADVA5-l5-domainCoriant-roadm2-otsi3-channel2', source: 'transponderADVA5-l5', target: '-domainCoriant-roadm2-otsi3-channel2', label: 'AT5-CR2', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant5-l5-domainCoriant-roadm2-otsi3-channel4', source: 'transponderCoriant5-l5', target: '-domainCoriant-roadm2-otsi3-channel4', label: 'CT5-CR2', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderADVA6-l6-domainCoriant-roadm3-otsi4-channel2', source: 'transponderADVA6-l6', target: '-domainCoriant-roadm3-otsi4-channel2', label: 'AT6-CR3', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
            { data: { id: 'transponderCoriant6-l6-domainCoriant-roadm3-otsi4-channel4', source: 'transponderCoriant6-l6', target: '-domainCoriant-roadm3-otsi4-channel4', label: 'CT6-CR3', length: 0, layer: 'OTSi' , domain: 'inter', 'operational-state': 'true' } },
 
            { data: { id: 'r1-transponderADVA2-c2transponderADVA2-l2', source: 'transponderADVA2-c2', target: 'transponderADVA2-l2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1-transponderADVA2-l2-domainADVA-roadm2-otsi3-channel2', source: 'transponderADVA2-l2', target: '-domainADVA-roadm2-otsi3-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainADVA-roadm2-otsi3-channel2-domainADVA-roadm2-oms2-channel2', source: '-domainADVA-roadm2-otsi3-channel2', target: '-domainADVA-roadm2-oms2-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainADVA-roadm2-oms2-channel2-domainADVA-roadm1-oms1-channel2', source: '-domainADVA-roadm2-oms2-channel2', target: '-domainADVA-roadm1-oms1-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainADVA-roadm1-oms1-channel2-domainADVA-roadm1-oms2-channel2', source: '-domainADVA-roadm1-oms1-channel2', target: '-domainADVA-roadm1-oms2-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainADVA-roadm1-oms2-channel2-domainADVA-roadm3-oms2-channel2', source: '-domainADVA-roadm1-oms2-channel2', target: '-domainADVA-roadm3-oms2-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainADVA-roadm3-oms2-channel2-domainADVA-roadm3-oms1-channel2', source: '-domainADVA-roadm3-oms2-channel2', target: '-domainADVA-roadm3-oms1-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainADVA-roadm3-oms1-channel2-domainCoriant-roadm1-oms3-channel2', source: '-domainADVA-roadm3-oms1-channel2', target: '-domainCoriant-roadm1-oms3-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainCoriant-roadm1-oms3-channel2-domainCoriant-roadm1-oms1-channel2', source: '-domainCoriant-roadm1-oms3-channel2', target: '-domainCoriant-roadm1-oms1-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainCoriant-roadm1-oms1-channel2-domainCoriant-roadm2-oms2-channel2', source: '-domainCoriant-roadm1-oms1-channel2', target: '-domainCoriant-roadm2-oms2-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainCoriant-roadm2-oms2-channel2-domainCoriant-roadm2-otsi3-channel2', source: '-domainCoriant-roadm2-oms2-channel2', target: '-domainCoriant-roadm2-otsi3-channel2', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1--domainCoriant-roadm2-otsi3-channel2transponderADVA5-l5', source: '-domainCoriant-roadm2-otsi3-channel2', target: 'transponderADVA5-l5', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
            { data: { id: 'r1-transponderADVA5-l5transponderADVA5-c5', source: 'transponderADVA5-l5', target: 'transponderADVA5-c5', 'route-id': 'Route1', type: 'route', 'life-cycle': 'inatalled', 'operational-state': 'true' } },
                                                                                                                                    
        ]
    },


    layout: {
        name: 'preset',
        padding: 5
    }
});
